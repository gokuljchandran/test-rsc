import { BrowserRouter, Route, Routes } from "react-router-dom";
import HomePage from "./components/HomePage";
import Newshomepage from "./components/Newshomepage";
import MovieDetail from "./components/MovieDetail";
import ErrorPage from "./components/ErrorPage";
import "./App.css";
import Gokulhomepage from "./components/Gokulhomepage";


function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Routes>
        <Route path="/newshome" element={<Newshomepage />}></Route>
        <Route path="/Gokulhomepage" element={<Gokulhomepage />}></Route>
          <Route path="/home" element={<HomePage />}></Route>
          <Route path="/details/:movieID" element={<MovieDetail />}></Route>
          <Route path="/*" element={<ErrorPage />}></Route>
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
