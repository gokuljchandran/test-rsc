import React from "react";
import "./MovieDetail.css";
import { useNavigate, useParams } from "react-router-dom";
import MOVIE_DETAILS from "../database/movies";

function MovieDetail() {
  const params = useParams();
  const navigate = useNavigate();
  console.log(params);
  const movieObject = MOVIE_DETAILS.movies.find(
    (movie) => movie.imdbID === params.movieID
  );

  const handleGoBack = () => {
    navigate("/home");
  };

  return (
    <div>
      <div className="btnhandle">
        <button className="btn" onClick={handleGoBack}>Go back to home</button>
      </div>
      <h3>{movieObject.Title}</h3>
      <h5>Released on: {movieObject.Released}</h5>
      <h5>Language: {movieObject.Language}</h5>
      <img src={movieObject.Poster} alt="Movie Poster" />
      <br />
      <table border={2}>

 <th> Date</th>
 <th> Desc</th>

      </table>
    </div>

  );
}

export default MovieDetail;
