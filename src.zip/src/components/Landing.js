import React from "react";
import { Link } from "react-router-dom";

function Landing() {
  const movieArray = [
    {
      id: 1,
      name: "A New Hope",
    },
    {
      id: 2,
      name: "The Empire Strikes Back",
    },
    {
      id: 3,
      name: "Return of the Jedi",
    },
    {
      id: 4,
      name: "The Phantom Menace",
    },
  ];
  return (
    <div>
      <ul>
        {movieArray.map((movie) => (
          <li key={movie.name}>
            <Link to={"/" + movie.id + "/details"}>{movie.name}</Link>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default Landing;
