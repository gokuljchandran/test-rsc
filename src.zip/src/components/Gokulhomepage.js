import React, { useEffect, useState } from "react";
import axios from "axios";
import { Link } from "react-router-dom";

function Gokulhomepage() {
    const [allNewsData, setallNewsData] = useState([]);
    
    useEffect(() => {
        axios.get("https://newsapi.org/v2/top-headlines/sources?apiKey=0a31735e455c461094ae833714703161")
            .then((response) => {
               // console.log("API Response:", response.data.sources);
                setallNewsData(response.data.sources);
            });
    }, []);

    return (
        <div>
            {
            allNewsData.map((news) => (
                     <Link to={`/details/${news.id}`} key={news.id}>{news.id}<br></br></Link>

               
            ))}
        </div>
    );
}

export default Gokulhomepage;
