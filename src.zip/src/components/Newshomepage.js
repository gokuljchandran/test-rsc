import React, { useEffect, useState } from "react";
import axios from "axios";
import "./Newshomepage.css";

function Newshomepage() {
    const [categories, setCategories] = useState([]);
    const [selectedCategory, setSelectedCategory] = useState(null);

    useEffect(() => {
        axios
            .get(
                "https://newsapi.org/v2/top-headlines/sources?apiKey=0a31735e455c461094ae833714703161"
            )
            .then((response) => {
                console.log("API Response:", response.data);
                const sources = response.data.sources || [];
                setCategories(getUniqueCategories(sources));
            })
            .catch((error) => {
                console.error("API Error:", error);
            });
    }, []);

    const getUniqueCategories = (sources) => {
        const uniqueCategories = [...new Set(sources.map((source) => source.category))];
        return uniqueCategories;
    };

    const capitalizeFirstLetter = (str) => {
        return str.charAt(0).toUpperCase() + str.slice(1);
    };

    return (
        <div>
            <div className="category-buttons">
                {categories.map((category) => (
                    <button
                        key={category}
                        onClick={() => setSelectedCategory(category)}
                        className={category === selectedCategory ? "active" : ""}
                    >
                        {capitalizeFirstLetter(category)}
                    </button>
                ))}
            </div>
        </div>
    );
}

export default Newshomepage;
