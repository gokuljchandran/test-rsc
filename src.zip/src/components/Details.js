import React, { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import axios from "axios";

function Details() {
  const routeParams = useParams();
  const navigate = useNavigate();
  const [movieDetails, setMovieDetails] = useState({});
  console.log("routeParams is", routeParams);

  useEffect(() => {
    axios
      .get("https://swapi.dev/api/films/" + routeParams.movieId)
      .then((response) => {
        setMovieDetails(response.data);
      });
  }, []);

  const handleBackClick = () => {
    navigate("/landing");
  };

  return movieDetails.title ? (
    <div>
      <b>{movieDetails.title}</b>
      <br />
      <p>
        <i>{movieDetails.opening_crawl}</i>
      </p>
      <br></br>
      <button onClick={handleBackClick}>Back</button>
    </div>
  ) : (
    <i>Loading...</i>
  );
}

export default Details;
